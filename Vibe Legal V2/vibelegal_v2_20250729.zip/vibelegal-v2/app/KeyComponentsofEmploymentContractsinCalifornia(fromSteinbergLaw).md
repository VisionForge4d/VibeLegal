## Key Components of Employment Contracts in California (from Steinberg Law)

### Employee and position details
- Employee's full name
- Designated position
- Official start date
- Job title and duties

### Compensation and benefits structure
- Salary, pay periods, bonus availability
- Overtime eligibility
- Health benefits, retirement plans
- Stock options, profit-sharing, tuition reimbursement, wellness initiatives

### Employee obligations
- Responsibilities, duties, performance expectations
- Working hours, schedule
- Reporting structure, communication channels

### Leave policies
- California Family Rights Act (CFRA): up to 12 weeks of job-protected leave for organizations with 5+ employees
- Paid Sick Leave (PSL): 5 days per year for employees who completed 90 days of service
- Other leaves: victims of crime/abuse, jury duty, military service

### Termination and severance policies
- Grounds for termination (for cause or without cause)
- Severance package details
- Notice periods, severance pay, benefits continuation, post-employment restrictions

### Non-disclosure agreements and intellectual property rights protection
- Safeguarding trade secrets and proprietary information
- Distinction from non-compete agreements (non-competes are generally unenforceable in CA)

### Resolving disputes and ensuring fairness
- Mechanisms to address conflicts/concerns
- Structured process for dispute resolution
- Promoting fair and respectful working environment




## Detailed Analysis of Essential Clauses

### At-Will Employment
**Description:** California is an at-will employment state, meaning that either the employer or the employee can terminate the employment relationship at any time, with or without cause, and with or without notice, unless there is an express agreement to the contrary. This fundamental principle is codified in California Labor Code § 2922.
**Legal Justification:** California Labor Code § 2922: "An employment, having no specified term, may be terminated at the will of either party on notice to the other. Employment for a specified term means an employment for a period greater than one month."

### Intellectual Property (IP) Assignment
**Description:** Employees typically assign rights to inventions created during their employment to the employer. However, California Labor Code § 2870 provides significant exceptions, stipulating that an invention developed on an employee's own time, without using employer's equipment, supplies, facilities, or trade secret information, and which does not relate to the employer's business or actual or demonstrably anticipated research and development, is exempt from assignment. Any employment agreement provision requiring an employee to assign such an invention is unenforceable.
**Legal Justification:** California Labor Code § 2870: "(a) Any provision in an employment agreement which provides that an employee shall assign, or offer to assign, any of his or her rights in an invention to his or her employer shall not apply to an invention that the employee developed entirely on his or her own time without using the employer’s equipment, supplies, facilities, or trade secret information except for those inventions that either: (1) Relate at the time of conception or reduction to practice of the invention to the employer’s business, or actual or demonstrably anticipated research or development of the employer; or (2) Result from any work performed by the employee for the employer. (b) To the extent a provision in an employment agreement purports to require an employee to assign an invention otherwise excluded from assignment under subdivision (a), the provision is against the public policy of this state and is unenforceable."

### Non-Compete Clauses
**Description:** Non-compete agreements are generally void and unenforceable in California. Business and Professions Code § 16600 broadly prohibits contracts that restrain anyone from engaging in a lawful profession, trade, or business. This means employers cannot prevent former employees from working for a competitor or starting a competing business, even if the agreement was signed outside of California. Recent legislation (SB 699 and AB 1076) further strengthens this prohibition, making non-compete clauses unlawful regardless of where and when the contract was signed, and imposing penalties on employers who attempt to enforce them.
**Legal Justification:** California Business and Professions Code § 16600: "Except as provided in this chapter, every contract by which anyone is restrained from engaging in a lawful profession, trade, or business of any kind is to that extent void." Also, refer to SB 699 and AB 1076 (effective January 1, 2024).

### Arbitration Clauses
**Description:** Many employment agreements include arbitration clauses, requiring disputes to be resolved through arbitration rather than litigation. While generally enforceable under federal law (Federal Arbitration Act), California law has historically been more protective of employee rights, sometimes challenging the enforceability of certain arbitration provisions, particularly those deemed unconscionable. Key considerations for enforceability in California include mutuality, adequate discovery, cost-sharing, and the availability of all statutory remedies. The California Supreme Court's decision in *Armendariz v. Foundation Health Psychcare Services, Inc.* sets forth specific requirements for arbitration agreements in the employment context.
**Legal Justification:** Federal Arbitration Act (9 U.S.C. § 1 et seq.) and California case law, notably *Armendariz v. Foundation Health Psychcare Services, Inc.* (2000) 24 Cal.4th 83.

### Compensation
**Description:** The contract must clearly define the employee's compensation, including salary, wages, bonuses, commissions, and any other forms of remuneration. It should specify the pay rate, pay periods, and the method of calculation for commissions or bonuses, if applicable. California Labor Code § 2751 requires that if commissions are a method of compensation, the contract must be in writing and set forth the method by which commissions shall be computed and paid.
**Legal Justification:** California Labor Code § 2751: "Whenever an employer enters into a contract of employment with an employee for services to be rendered within this state and the contemplated method of payment involves commissions, the contract shall be in writing and shall set forth the method by which the commissions shall be computed and paid."

### Confidentiality and Non-Disclosure
**Description:** This clause protects the employer's confidential and proprietary information, trade secrets, and other sensitive business data. It typically prohibits the employee from disclosing or using such information outside the scope of their employment, both during and after their employment. Unlike non-compete clauses, well-drafted confidentiality and non-disclosure agreements are generally enforceable in California, as they protect legitimate business interests.
**Legal Justification:** California Uniform Trade Secrets Act (Civil Code § 3426 et seq.).

### Employee Classification (Exempt/Non-Exempt)
**Description:** Properly classifying employees as exempt or non-exempt from overtime and other wage and hour laws is crucial in California due to its strict wage and hour regulations. The contract should reflect the employee's classification and the basis for that classification (e.g., executive, administrative, professional exemptions), ensuring compliance with California's complex duties and salary tests.
**Legal Justification:** California Labor Code and Wage Orders issued by the Industrial Welfare Commission (IWC).

### Governing Law and Jurisdiction
**Description:** This clause specifies that California law will govern the employment agreement and that any disputes will be resolved in California courts or arbitration. Given California's strong public policy favoring employee protections, it is generally advisable for contracts with California employees to explicitly state that California law applies, even if the employer is based elsewhere.
**Legal Justification:** California Code of Civil Procedure § 410.10 (long-arm statute) and general principles of contract law and choice of law.

### Entire Agreement
**Description:** This clause states that the written contract constitutes the entire agreement between the parties, superseding all prior discussions, negotiations, and agreements. It helps prevent claims based on oral promises or understandings not included in the final written document.
**Legal Justification:** General principles of contract law (Parol Evidence Rule).

### Severability
**Description:** This clause provides that if any provision of the contract is found to be invalid or unenforceable, the remaining provisions will remain in full force and effect. This helps to ensure that the entire contract is not invalidated due to a defect in one specific clause.
**Legal Justification:** General principles of contract law.

### Offer of Employment and Conditions
**Description:** This section outlines the formal offer of employment, including the position, start date, and any conditions precedent to employment (e.g., background check, drug screening, verification of eligibility to work). It clarifies that the offer is contingent upon meeting these conditions.
**Legal Justification:** General principles of contract law.

### Benefits
**Description:** This clause details the employee benefits provided by the employer, such as health insurance, dental insurance, vision insurance, retirement plans (e.g., 401k), paid time off (PTO), holidays, and other perks. It may refer to separate benefit plan documents for full details.
**Legal Justification:** Employee Retirement Income Security Act (ERISA) for certain benefits, and California law for others (e.g., Paid Sick Leave).

### Termination Provisions
**Description:** Beyond at-will employment, this section can detail specific circumstances for termination, such as termination for cause (e.g., misconduct, poor performance) and termination without cause, including any notice periods or severance pay arrangements. It should align with California's at-will doctrine while providing clarity on processes.
**Legal Justification:** California Labor Code § 2922 and general contract principles.

### Return of Company Property
**Description:** This clause requires the employee to return all company property (e.g., laptops, phones, documents, access cards) upon termination of employment. It ensures the employer retains control over its assets and sensitive information.
**Legal Justification:** General principles of property law and employer's right to protect assets.

### Modifications
**Description:** This clause specifies that any modifications to the employment agreement must be in writing and signed by both parties. This prevents informal or oral changes to the contract.
**Legal Justification:** General principles of contract law (Statute of Frauds for certain agreements).

### Notice
**Description:** This clause outlines the method and address for providing formal notices between the employer and employee, ensuring that all official communications are properly delivered.
**Legal Justification:** General principles of contract law.




## Suggested Example Documents for `examples/`

Based on the research, the following types of documents and sources could be valuable for inclusion under an `examples/` directory. Please note that direct downloads or links are provided where publicly available and permissible. Always consult with legal counsel for specific needs.

*   **SHRM (Society for Human Resource Management) Sample Provisions:** SHRM often provides sample clauses and contract provisions that are widely used and generally align with best practices. While not California-specific in all cases, they can serve as a good starting point for general contract structure.
    *   **Reference:** [SHRM Employment Contract Provisions](https://www.shrm.org/topics-tools/tools/forms/employment-contract-provisions)

*   **Juro California Employment Contract Template:** Juro offers a free California-specific employment contract template that can be used as inspiration for structure and content.
    *   **Reference:** [Juro California Employment Contract Template](https://juro.com/contract-templates/california-employment-contract)

*   **UC Santa Barbara (UCSB) Employment Contract Template (DOCX):** University systems often have well-vetted templates for their employment agreements. The UCSB template provides a practical example of an exempt employee contract.
    *   **Reference:** [UCSB Employment Contract Template (Direct Download)](https://www.hr.ucsb.edu/sites/default/files/docs/forms/EmploymentContractTemplate_PSS_General_Exempt.docx)

*   **Judicial Council of California Standard Agreement (PDF):** While not strictly an employment contract, the Judicial Council of California provides standard agreement coversheets and sample agreements for services, which can offer insights into formatting and standard legal language used in California state contexts.
    *   **Reference:** [Judicial Council of California Standard Agreement (Direct Download)](https://courts.ca.gov/system/files/solicitation-request-document/fs-2019-05-dgf-attach-d-sample-agreement.pdf)

*   **SEC Filings (e.g., Model Employment Agreement):** Publicly filed agreements with the SEC (U.S. Securities and Exchange Commission) often contain comprehensive employment agreements from various companies. These can provide real-world examples of clauses and structures, though they may not always be tailored specifically for California law and should be reviewed carefully.
    *   **Reference (Example):** [SEC Filing - Model Employment Agreement](https://www.sec.gov/Archives/edgar/data/1141197/000110313204000018/exhibit101.pdf)

*   **Legal Templates / Law Firm Samples:** Many legal template websites and law firms provide sample California employment contracts. These can be useful for comparing different approaches and ensuring comprehensive coverage of clauses.
    *   **Reference (Example):** [LegalTemplates California Employment Contract](https://legaltemplates.net/form/employment-contract/california-ca/)
    *   **Reference (Example):** [Cislo & Thomas LLP - Employment Agreement (PDF)](https://cisloandthomas.com/wp-content/uploads/2012/08/Employment_Agreement.pdf)

It is important to note that while these examples provide valuable reference points, they should always be reviewed by legal counsel to ensure full compliance with the latest California labor laws and specific business needs.

