# VibeLegal — LLM Switch Integration (Proposal + Implementation Plan)

Use the LLM Switch as an AI copilot for contract workflows **without** leaking keys or letting the model write enforceable text.
The switch handles messy NL in/out (parse briefs, suggest clauses, summarize); VibeLegal keeps templates, rules, and rendering as the source of truth.

## Goals (this phase)
- Backend-only bridge from VibeLegal → LLM Switch (`http://localhost:8080/api`).
- Endpoints in VibeLegal:
  - `POST /api/contracts/parse-brief` → NL brief → strict JSON `ContractSpec`.
  - *(Optional)* `POST /api/llm-switch` → admin/dev passthrough for testing.
- Final contract text continues to come from VibeLegal templates/clauses.

## Non-Goals
- No streaming/tools/retries.
- No direct frontend → provider calls (no exposed API keys).
- LLM does **not** assemble enforceable contract text.

## Architecture
```
Frontend ──► VibeLegal API (server.js) ──► LLM Switch @ :8080/api/llm ──► Providers (OpenAI/Groq)
             ▲                                                    │
             └──────── Templates/Rules/Render (VibeLegal) ◄───────┘
```

## Deliverables
- `switch/` folder (this doc, env template, request examples, docs/ for your PDF).
- Minimal patch to `backend/server.js` (helper + route).

## Acceptance Criteria
- `POST /api/contracts/parse-brief` → `{ ok: true, spec }`
- DRY_RUN on the Switch returns validation; DRY_RUN off returns real model output.
- No CORS changes required; existing routes unchanged.
