# VibeLegal — Switch Setup

This wires the VibeLegal backend to the **LLM Switch** service at `http://localhost:8080/api`.

## 0) Prereqs
- LLM Switch stack is running and healthy:
  ```bash
  curl -s http://localhost:8080/api/health | jq
  ```
- VibeLegal backend running locally on port **5000** (or as configured).

## 1) Install dependency (backend only)
```bash
cd backend
npm install undici
```

## 2) Configure env (backend/.env or .env.example)
Append these keys:
```ini
# LLM Switch
LLM_SWITCH_URL=http://localhost:8080/api
LLM_PROVIDER=groq
LLM_MODEL=llama-3.1-8b-instant

# JWT (replace before production)
JWT_SECRET=replace_with_secure_random_string

# Postgres (example; align with your local setup)
PGUSER=zod
PGHOST=localhost
PGDATABASE=vibelegal
PGPORT=5432
PGPASSWORD=saddleup123
```

## 3) Patch backend/server.js
**Import**
```js
const { fetch } = require('undici');
```

**Helper**
```js
async function callLLMSwitch(messages, provider = process.env.LLM_PROVIDER || 'groq', model = process.env.LLM_MODEL || 'llama-3.1-8b-instant') {
  const base = process.env.LLM_SWITCH_URL || 'http://localhost:8080/api';
  const r = await fetch(`${base}/llm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ provider, model, messages })
  });
  const data = await r.json();
  if (!data?.ok) throw new Error(data?.error || 'llm-switch call failed');
  return data; // { ok, provider, text, ... }
}
```

**Route**
```js
app.post('/api/contracts/parse-brief', authenticateToken, async (req, res) => {
  try {
    const { brief } = req.body || {};
    if (!brief) return res.status(400).json({ ok:false, error: 'brief is required' });

    const messages = [
      { role: 'system', content: 'You convert plain English briefs into a strict JSON ContractSpec. Output ONLY JSON. No prose.' },
      { role: 'user', content: `Brief:\n${brief}\nReturn strict JSON for ContractSpec with ISO dates (YYYY-MM-DD).` }
    ];

    const out = await callLLMSwitch(messages);
    const spec = JSON.parse(out.text || '{}');
    return res.json({ ok: true, spec, debug: process.env.DRY_RUN === '1' ? out : undefined });
  } catch (err) {
    console.error('parse-brief error:', err);
    res.status(500).json({ ok:false, error: 'Failed to parse brief' });
  }
});
```

*(Optional) Dev passthrough*
```js
app.post('/api/llm-switch', authenticateToken, async (req, res) => {
  try {
    const { provider, model, messages } = req.body || {};
    const out = await callLLMSwitch(messages, provider, model);
    res.json(out);
  } catch (err) {
    console.error('llm-switch proxy error:', err);
    res.status(502).json({ ok:false, error: 'llm-switch proxy failed' });
  }
});
```

## 4) Validate
```bash
# Switch health
curl -s http://localhost:8080/api/health | jq

# VibeLegal health
curl -s http://localhost:5000/api/health | jq

# Parse brief (needs a JWT)
curl -s -X POST http://localhost:5000/api/contracts/parse-brief \
  -H "Authorization: Bearer <TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"brief":"Two-party NDA between Acme (NY) and Beta (CA), one-year term, mutual confidentiality."}' | jq
```
