Place your PDF(s) for the integration here.
Recommended name: VibeLegal-Integration.pdf
This folder is included in the Switch Pack zip for easy sharing.
